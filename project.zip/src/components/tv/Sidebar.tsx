import { Link, useRouterState } from "@tanstack/react-router";
import { Clapperboard, Home, MonitorPlay, Tv } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Início", icon: Home },
  { to: "/live", label: "Canais", icon: Tv },
  { to: "/filmes", label: "Filmes", icon: Clapperboard },
  { to: "/series", label: "Séries", icon: MonitorPlay },
] as const;

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className="fixed left-0 top-0 z-30 flex h-screen w-24 flex-col items-center gap-3 border-r border-border bg-surface/80 py-8 backdrop-blur">
      <div
        className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl text-lg font-black text-primary-foreground"
        style={{ background: "var(--gradient-brand)" }}
      >
        TV
      </div>
      {items.map(({ to, label, icon: Icon }) => {
        const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
        return (
          <Link
            key={to}
            to={to}
            tabIndex={0}
            data-tv-focusable=""
            className={cn(
              "tv-focusable tv-focus-ring tv-pop-sm flex h-16 w-16 flex-col items-center justify-center gap-1 rounded-2xl text-[11px] font-medium text-muted-foreground",
              active && "bg-elevated text-foreground",
            )}
          >
            <Icon className="h-6 w-6" />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
