import { forwardRef, type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  /** Marks this element as the preferred initial focus target of the page. */
  initialFocus?: boolean | undefined;
  pop?: "none" | "sm" | "lg" | undefined;
};

/** Remote-control focusable primitive: DPad aware, scales and glows on focus. */
export const Focusable = forwardRef<HTMLButtonElement, Props>(function Focusable(
  { className, initialFocus, pop = "sm", ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type="button"
      tabIndex={0}
      data-tv-focusable=""
      {...(initialFocus ? { "data-tv-autofocus": "" } : {})}
      className={cn(
        "tv-focusable tv-focus-ring text-left",
        pop === "lg" && "tv-pop",
        pop === "sm" && "tv-pop-sm",
        className,
      )}
      {...props}
    />
  );
});
